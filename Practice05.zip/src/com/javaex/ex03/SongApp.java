package com.javaex.ex03;

public class SongApp {

	public static void main(String[] args){
		
		
	}

}


