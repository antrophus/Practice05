package com.javaex.ex09;

public class StringUtil {
    
    public static String concatString(){
       
        //메소드 내용작성
        
    }

}
