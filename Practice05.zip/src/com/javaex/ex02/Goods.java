package com.javaex.ex02;

public class Goods {

	
	
}




