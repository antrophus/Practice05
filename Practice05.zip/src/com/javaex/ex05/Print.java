package com.javaex.ex05;

public class Print {
    
    public void printer(int val){
        System.out.println(val);
    }

    //메소드  3개 를 작성하세요
    
}
